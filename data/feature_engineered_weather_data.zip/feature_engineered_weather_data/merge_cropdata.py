import pandas as pd
import os

# Define paths
crop_file = "crop_nostd1.csv"
weather_folder = "seasonal_outputs"

# Load crop data
crop_df = pd.read_csv(crop_file)

# Initialize empty list to store weather DataFrames
weather_list = []

# Process each weather file in the folder
for filename in os.listdir(weather_folder):
    if filename.endswith(".csv"):
        file_path = os.path.join(weather_folder, filename)
        weather_df = pd.read_csv(file_path)

        # Standardize column names
        weather_df.rename(columns={"year_span": "Year", "season": "Crop Season"}, inplace=True)

        # Extract state name from filename (Assuming format: State.csv)
        state_name = os.path.splitext(filename)[0]
        weather_df["State"] = state_name

        # Append to list
        weather_list.append(weather_df)

# Concatenate all weather DataFrames
weather_df = pd.concat(weather_list, ignore_index=True)

# Merge datasets
crop_df = pd.merge(crop_df, weather_df, on=["State", "Crop Season", "Year"], how="left", suffixes=("", "_weather"))

# Save the merged dataset
output_file = "merged_data.csv"
crop_df.to_csv(output_file, index=False)

print(f"Merge complete. File saved at {output_file}")