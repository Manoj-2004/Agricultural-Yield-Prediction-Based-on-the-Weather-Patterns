import pandas as pd

# Load dataset
df = pd.read_csv("updatedAgriDataset1.csv")

# Compute dynamic thresholds
lower_threshold = df["iif"].quantile(0.33)  # 33rd percentile
upper_threshold = df["iif"].quantile(0.67)  # 67th percentile

# Classification based on thresholds
def classify_iif(iif):
    if iif < lower_threshold:
        return "Rainfed"
    elif iif < upper_threshold:
        return "Mixed"
    else:
        return "Irrigated"

df["iif_classified"] = df["iif"].apply(classify_iif)

# Save the updated dataset
df.to_csv("classified_dataset.csv", index=False)

print("Classification complete. Check 'classified_dataset.csv'.")
