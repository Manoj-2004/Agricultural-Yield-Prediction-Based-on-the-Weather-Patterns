import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

# Step 1: Load the dataset
df = pd.read_csv("assam_processed.csv")

# Step 2: Select relevant environmental features
features = ['swvl3', 'swvl4', 'cvl', 'lai_lv', 'uvb', 'tp',
            't2m_C', 'windSpeed', 'relativeHumidity', 'wbi', 'rsm']
X = df[features]

# Step 3: Normalize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 4: Apply DBSCAN clustering
dbscan = DBSCAN(eps=1.5, min_samples=10)
df['Cluster'] = dbscan.fit_predict(X_scaled)

# Step 5: Compute cluster weights
cluster_counts = df['Cluster'].value_counts().to_dict()
total_points = len(df)
cluster_weights = {k: v / total_points for k, v in cluster_counts.items()}

# Step 6: Determine season (Kharif: Jun–Oct, Rabi: Nov–Mar)
def determine_season(valid_time):
    month = int(str(valid_time)[4:6])
    if 6 <= month <= 10:
        return 'Kharif'
    elif month >= 11 or month <= 3:
        return 'Rabi'
    else:
        return 'Other'

df['Season'] = df['valid_time'].apply(determine_season)
df = df[df['Season'].isin(['Kharif', 'Rabi'])]  # Keep only Kharif and Rabi

# Step 7: Compute weighted statistics per cluster and season
def weighted_stats(group):
    cluster = group.name[0]
    weight = cluster_weights.get(cluster, 0)
    means = group[features].mean() * weight
    stds = group[features].std()
    vars_ = group[features].var()
    
    result = pd.concat([
        means.add_suffix('_mean'),
        stds.add_suffix('_std'),
        vars_.add_suffix('_var')
    ])
    return result

summary = df.groupby(['Cluster', 'Season']).apply(weighted_stats).reset_index()

# Step 8: Save the result
summary.to_csv("assam_processed_seasonal.csv", index=False)
print("File saved as assam_processed_seasonal.csv")
